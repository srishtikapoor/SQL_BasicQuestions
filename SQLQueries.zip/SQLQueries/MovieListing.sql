create table movie2(
MovieID int identity,
MovieName nvarchar(20),
AudiID int,
ShowTime int,
primary key(MovieID)
)
exec SelectAll;
CREATE PROCEDURE addValues
AS
INSERT INTO movie2 values(1,'hello',1725);
GO;

insert into movie2 values('Kabira',2,1520);
insert into movie2 values('Musafir',1,1010);
insert into movie2 values('Aamir',3,2120);

select * from movie2

create table Auditorium(
AudiID int,
MovieID int,
primary key(AudiID),
foreign key(MovieID) references movie2(MovieID),
)

exec SelectAll;