 use MovieListing;
create PROCEDURE SelectAll
AS
SELECT * FROM movie2
GO;

CREATE PROCEDURE addValues
AS
INSERT INTO movie2 values(1,'hello',1725)
GO;