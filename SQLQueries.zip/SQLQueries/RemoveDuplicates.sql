use RemoveDuplicates
create table Info3(Id int, Name varchar(20))
Insert into Info3 Values(505, 'shanker kumar');
Insert into Info3 Values(505, 'xyz');
Insert into Info3 Values(404, 'shristi kapoor');
delete from Info3 where Id in(select Id from Info3 group by Id having  count(*) >1);
select * from Info3;